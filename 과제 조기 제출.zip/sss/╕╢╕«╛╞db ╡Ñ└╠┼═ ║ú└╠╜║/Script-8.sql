CREATE DATABASE practice_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;



USE practice_db;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);







CREATE DATABASE flatfish_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
 USE flatfish_db;

 
 create table flatfish (
 species_id          INT AUTO_INCREMENT PRIMARY KEY COMMENT '어종 고유 번호',
    korean_name         VARCHAR(50) NOT NULL COMMENT '한국명',
    scientific_name     VARCHAR(100) NOT NULL COMMENT '학명',
    english_name        VARCHAR(100) COMMENT '영문명',
    family_name         VARCHAR(50) COMMENT '과명',
    max_length          DECIMAL(5,2) COMMENT '최대 길이(cm)',
    max_weight          DECIMAL(7,2) COMMENT '최대 무게(g)',ㅈ
    lifespan            INT COMMENT '수명(년)',
    habitat_depth_min   INT COMMENT '서식 최소 수심(m)',
    habitat_depth_max   INT COMMENT '서식 최대 수심(m)',
    water_temp_min      DECIMAL(4,1) COMMENT '적정 수온 최소(°C)',
    water_temp_max      DECIMAL(4,1) COMMENT '적정 수온 최대(°C)',
    breeding_season     VARCHAR(20) COMMENT '번식기',
    conservation_status VARCHAR(20) DEFAULT 'LC' COMMENT '보존상태',
    description         TEXT COMMENT '설명',
    image_url           VARCHAR(255) COMMENT '이미지 URL',
    create_date         DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '자료 생성일',
    update_date         DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '자료 수정일'
);
 


INSERT INTO flatfish (
korean_name,
scientific_name,
english_name,
family_name,
max_length,
max_weight,
lifespan,
habitat_depth_min,
habitat_depth_max,
water_temp_min,
water_temp_max,
breeding_season,
conservation_status,
description,
image_url
) VALUES (
'물가자미',
'Eopsetta grigorjewi',
'Shotted halibut',
'가자미목(目)가자미과(科)',
38.3,
486,
10,
1,
200,
5.0,
12.0,
'6월에서 8월 사이',
'DD',
'입은 큰 편이고 위턱의 끝은 눈의 중앙 아래까지 도달한다. 비늘은 눈이 있는 쪽은 빗비늘, 눈이 없는 쪽은 둥근비늘이다. 옆줄은 가슴지느러미 위부분에서 반달모양으로 볼록하게 휘어져 있다. 등지느러미는 윗눈 앞쪽의 눈이 없는 쪽에서 시작한다. 가슴지느러미의 중간과 아래쪽의 연조는 갈라져 있다(눈이 있는 쪽의 가슴지느러미 연조수는 11개이며, 그 중 7개가 갈라져 있다). 두 눈 사이는 편평하다.. .',
'https://www.nifs.go.kr/contents/actionContentsCons0088.do'
);









CREATE DATABASE marine CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


USE marine;

CREATE TABLE sea (
    species_id          INT AUTO_INCREMENT PRIMARY KEY COMMENT '어종 고유 번호',
    korean_name         VARCHAR(50) NOT NULL COMMENT '한국명',
    scientific_name     VARCHAR(100) NOT NULL COMMENT '학명',
    english_name        VARCHAR(100) COMMENT '영문명',
    family_name         VARCHAR(50) COMMENT '과명',
    max_length          DECIMAL(5,2) COMMENT '최대 길이(cm)',
    max_weight          DECIMAL(7,2) COMMENT '최대 무게(g)',
    lifespan            INT COMMENT '수명(년)',
    habitat_depth_min   INT COMMENT '서식 최소 수심(m)',
    habitat_depth_max   INT COMMENT '서식 최대 수심(m)',
    water_temp_min      DECIMAL(4,1) COMMENT '적정 수온 최소(°C)',
    water_temp_max      DECIMAL(4,1) COMMENT '적정 수온 최대(°C)',
    breeding_season     VARCHAR(20) COMMENT '번식기',
    conservation_status VARCHAR(20) DEFAULT 'LC' COMMENT '보존상태',
    description         TEXT COMMENT '설명',
    image_url           VARCHAR(255) COMMENT '이미지 URL',
    create_date         DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '자료 생성일',
    update_date         DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '자료 수정일'
);

INSERT INTO sea (
    korean_name, scientific_name, english_name, family_name,
    max_length, max_weight, lifespan,
    habitat_depth_min, habitat_depth_max,
    water_temp_min, water_temp_max,
    breeding_season, conservation_status,
    description, image_url
) VALUES
(
    '대왕오징어', 'Architeuthis dux', 'Giant Squid', 'Architeuthidae',
    900.00, 99000.00, 5,
    300, 1000,
    4.0, 10.0,
    '봄~여름', 'LC',
    '심해에 서식하는 거대한 오징어로, 거의 알려지지 않은 생물입니다.', 
    'https://upload.wikimedia.org/wikipedia/commons/6/6f/Giant_Squid.jpg'
),
(
    '고래상어', 'Rhincodon typus', 'Whale Shark', 'Rhincodontidae',
    950.00, 99999.99, 70,
    0, 150,
    21.0, 25.0,
    '5월~9월', 'EN',
    '세계에서 가장 큰 어류로 온순하며 주로 플랑크톤을 먹습니다.',
    'https://upload.wikimedia.org/wikipedia/commons/0/0b/Whale_shark_Georgia_aquarium.jpg'
),
(
    '개복치', 'Mola mola', 'Ocean Sunfish', 'Molidae',
    300.00, 75000.00, 10,
    0, 600,
    12.0, 24.0,
    '여름', 'VU',
    '몸이 납작하고 거대한 해양 어류로 따뜻한 바다에 서식합니다.',
    'https://upload.wikimedia.org/wikipedia/commons/7/71/Mola_mola_Lisbon_Oceanarium_02.jpg'
),
(
    '청새치', 'Makaira nigricans', 'Blue Marlin', 'Istiophoridae',
    480.00, 82000.00, 27,
    0, 200,
    22.0, 30.0,
    '여름~가을', 'LC',
    '빠른 속도로 헤엄치는 큰 어류로, 스포츠 피싱 대상으로 인기 있습니다.',
    'https://upload.wikimedia.org/wikipedia/commons/4/4b/Blue_marlin.jpg'
),
(
    '심해아귀', 'Melanocetus johnsonii', 'Anglerfish', 'Melanocetidae',
    18.00, 1500.00, 20,
    300, 1500,
    1.0, 6.0,
    '가을~겨울', 'LC',
    '심해에 서식하며 빛을 내는 미끼로 먹이를 유인하는 독특한 생물입니다.',
    'https://upload.wikimedia.org/wikipedia/commons/3/3f/Melanocetus_johnsonii.png'
);

