// 로그인 처리 JavaScript (c.js)

// 사용자 데이터 관리 객체
const UserManager = {
    // 로컬 스토리지에서 사용자 목록 가져오기
    getUsers: function() {
        const users = localStorage.getItem('flatfish_users');
        return users ? JSON.parse(users) : [];
    },

    // 로컬 스토리지에 사용자 목록 저장
    saveUsers: function(users) {
        localStorage.setItem('flatfish_users', JSON.stringify(users));
    },

    // 사용자 찾기 (아이디로)
    findUserByUsername: function(username) {
        const users = this.getUsers();
        return users.find(user => user.username === username);
    },

    // 마지막 로그인 시간 업데이트
    updateLastLogin: function(username) {
        const users = this.getUsers();
        const userIndex = users.findIndex(user => user.username === username);
        if (userIndex !== -1) {
            users[userIndex].lastLogin = new Date().toISOString();
            this.saveUsers(users);
        }
    }
};

// 메시지 표시 함수
function showMessage(message, type = 'error') {
    const messageArea = document.getElementById('messageArea');
    messageArea.innerHTML = `<div class="message ${type}">${message}</div>`;
    
    // 3초 후 메시지 자동 제거
    setTimeout(() => {
        messageArea.innerHTML = '';
    }, 3000);
}

// 로그인 처리 함수
function handleLogin(event) {
    event.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    // 입력값 검증
    if (!username || !password) {
        showMessage('아이디와 비밀번호를 모두 입력해주세요.');
        return;
    }

    // 사용자 찾기
    const user = UserManager.findUserByUsername(username);
    
    if (!user) {
        showMessage('존재하지 않는 아이디입니다.');
        return;
    }

    // 비밀번호 확인
    if (user.password !== password) {
        showMessage('비밀번호가 일치하지 않습니다.');
        return;
    }

    // 로그인 성공
    try {
        // 마지막 로그인 시간 업데이트
        UserManager.updateLastLogin(username);
        
        // 현재 로그인 사용자 정보 저장
        localStorage.setItem('currentUser', JSON.stringify(user));
        
        // 성공 메시지
        showMessage('로그인 성공!', 'success');
        
        // 환영 화면 표시
        showWelcomeScreen(user);
        
    } catch (error) {
        console.error('로그인 에러:', error);
        showMessage('로그인 중 오류가 발생했습니다.');
    }
}

// 환영 화면 표시
function showWelcomeScreen(user) {
    // 로그인 폼 숨기기
    document.querySelector('.login-box').style.display = 'none';
    
    // 환영 화면 보이기
    const welcomeScreen = document.getElementById('welcomeScreen');
    welcomeScreen.style.display = 'block';
    
    // 사용자 정보 표시
    const userInfo = document.getElementById('userInfo');
    const registrationDate = new Date(user.registrationDate).toLocaleDateString();
    const lastLogin = user.lastLogin ? new Date(user.lastLogin).toLocaleString() : '첫 로그인';
    
    userInfo.innerHTML = `
        <h3>${user.username}님, 환영합니다!</h3>
        <p><strong>이메일:</strong> ${user.email}</p>
        <p><strong>가입일:</strong> ${registrationDate}</p>
        <p><strong>마지막 로그인:</strong> ${lastLogin}</p>
    `;
}

// 메인 페이지로 이동
function goToMainPage() {
    alert('메인 페이지로 이동합니다.');
    // 실제로는 메인 페이지로 리다이렉트
    window.location.href = 'index.jsp';
}

// 로그아웃
function logout() {
    if (confirm('로그아웃 하시겠습니까?')) {
        // 현재 사용자 정보 제거
        localStorage.removeItem('currentUser');
        
        // 페이지 새로고침
        window.location.reload();
    }
}

// 자동 로그인 체크 (페이지 로드시)
function checkAutoLogin() {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
        const user = JSON.parse(currentUser);
        showWelcomeScreen(user);
    }
}

// 페이지 로드 완료 후 실행
document.addEventListener('DOMContentLoaded', function() {
    // 폼 제출 이벤트 연결
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // 자동 로그인 체크
    checkAutoLogin();

    // Enter 키로 로그인
    document.addEventListener('keypress', function(event) {
        if (event.key === 'Enter' && event.target.tagName !== 'BUTTON') {
            const loginForm = document.getElementById('loginForm');
            if (loginForm && loginForm.style.display !== 'none') {
                handleLogin(event);
            }
        }
    });

    console.log('로그인 페이지 로드 완료');
});

// 개발용 함수들
function showAllUsers() {
    console.table(UserManager.getUsers());
}

function createTestUser() {
    if (!UserManager.findUserByUsername('test')) {
        const testUser = {
            username: 'test',
            password: 'test123',
            email: 'test@example.com',
            registrationDate: new Date().toISOString(),
            lastLogin: null
        };
        
        const users = UserManager.getUsers();
        users.push(testUser);
        UserManager.saveUsers(users);
        
        console.log('테스트 사용자 생성: ID=test, PW=test123');
    }
}

// 테스트 사용자 자동 생성
createTestUser();

// 전역 함수로 노출
window.showAllUsers = showAllUsers;
window.createTestUser = createTestUser;