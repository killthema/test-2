

// 사용자 데이터 관리 객체
const UserManager = {
    // 로컬 스토리지에서 사용자 목록 가져오기
    getUsers: function() {
        const users = localStorage.getItem('flatfish_users');
        return users ? JSON.parse(users) : [];
    },

    // 로컬 스토리지에 사용자 목록 저장
    saveUsers: function(users) {
        localStorage.setItem('flatfish_users', JSON.stringify(users));
    },

    // 새 사용자 추가
    addUser: function(userData) {
        const users = this.getUsers();
        users.push(userData);
        this.saveUsers(users);
    },

    // 사용자 존재 여부 확인 (아이디로)
    userExists: function(username) {
        const users = this.getUsers();
        return users.some(user => user.username === username);
    },

    // 이메일 중복 확인
    emailExists: function(email) {
        const users = this.getUsers();
        return users.some(user => user.email === email);
    }
};

// 폼 유효성 검사 함수들
const Validation = {
    // 아이디 유효성 검사
    validateUsername: function(username) {
        const usernameRegex = /^[a-zA-Z0-9]{4,20}$/;
        if (!username) {
            return '아이디를 입력해주세요.';
        }
        if (!usernameRegex.test(username)) {
            return '아이디는 4-20자의 영문, 숫자만 사용 가능합니다.';
        }
        if (UserManager.userExists(username)) {
            return '이미 사용중인 아이디입니다.';
        }
        return null;
    },

    // 비밀번호 유효성 검사
    validatePassword: function(password) {
        const passwordRegex = /^(?=.*[a-zA-Z])(?=.*[0-9]).{6,}$/;
        if (!password) {
            return '비밀번호를 입력해주세요.';
        }
        if (!passwordRegex.test(password)) {
            return '비밀번호는 6자 이상, 영문+숫자 조합이어야 합니다.';
        }
        return null;
    },

    // 비밀번호 확인 검사
    validatePasswordConfirm: function(password, password2) {
        if (!password2) {
            return '비밀번호 확인을 입력해주세요.';
        }
        if (password !== password2) {
            return '비밀번호가 일치하지 않습니다.';
        }
        return null;
    },

    // 이메일 유효성 검사
    validateEmail: function(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email) {
            return '이메일을 입력해주세요.';
        }
        if (!emailRegex.test(email)) {
            return '올바른 이메일 형식이 아닙니다.';
        }
        if (UserManager.emailExists(email)) {
            return '이미 사용중인 이메일입니다.';
        }
        return null;
    }
};

// 메시지 표시 함수
function showMessage(message, type = 'error') {
    // 기존 메시지 제거
    const existingMessage = document.querySelector('.message');
    if (existingMessage) {
        existingMessage.remove();
    }

    // 새 메시지 생성
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.innerHTML = message;

    // 폼 위에 메시지 삽입
    const form = document.getElementById('registerForm');
    form.insertBefore(messageDiv, form.firstChild);

    // 3초 후 메시지 자동 제거
    setTimeout(() => {
        if (messageDiv.parentNode) {
            messageDiv.remove();
        }
    }, 5000);
}

// 실시간 유효성 검사 (입력 중 검사)
function setupRealTimeValidation() {
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const password2Input = document.getElementById('password2');
    const emailInput = document.getElementById('email');

    // 아이디 실시간 검사
    usernameInput.addEventListener('blur', function() {
        const error = Validation.validateUsername(this.value.trim());
        showFieldError('username', error);
    });

    // 비밀번호 실시간 검사
    passwordInput.addEventListener('blur', function() {
        const error = Validation.validatePassword(this.value);
        showFieldError('password', error);
    });

    // 비밀번호 확인 실시간 검사
    password2Input.addEventListener('blur', function() {
        const password = passwordInput.value;
        const error = Validation.validatePasswordConfirm(password, this.value);
        showFieldError('password2', error);
    });

    // 이메일 실시간 검사
    emailInput.addEventListener('blur', function() {
        const error = Validation.validateEmail(this.value.trim());
        showFieldError('email', error);
    });
}

// 필드별 에러 메시지 표시
function showFieldError(fieldId, error) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(fieldId + '-error');
    
    // 기존 에러 메시지 제거
    if (errorElement) {
        errorElement.remove();
    }

    if (error) {
        // 에러 있을 때
        field.style.borderColor = '#dc3545';
        
        const errorDiv = document.createElement('div');
        errorDiv.id = fieldId + '-error';
        errorDiv.className = 'field-error';
        errorDiv.textContent = error;
        
        field.parentNode.appendChild(errorDiv);
    } else {
        // 에러 없을 때
        field.style.borderColor = '#28a745';
    }
}

// 회원가입 처리
function handleRegister(event) {
    event.preventDefault(); // 기본 폼 제출 방지

    // 입력값 가져오기
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const password2 = document.getElementById('password2').value;
    const email = document.getElementById('email').value.trim();

    // 전체 유효성 검사
    const errors = [];
    
    const usernameError = Validation.validateUsername(username);
    if (usernameError) errors.push(usernameError);

    const passwordError = Validation.validatePassword(password);
    if (passwordError) errors.push(passwordError);

    const password2Error = Validation.validatePasswordConfirm(password, password2);
    if (password2Error) errors.push(password2Error);

    const emailError = Validation.validateEmail(email);
    if (emailError) errors.push(emailError);

    // 에러가 있으면 메시지 표시하고 중단
    if (errors.length > 0) {
        showMessage(errors[0], 'error');
        return;
    }

    try {
        // 새 사용자 데이터 생성
        const userData = {
            username: username,
            password: password, // 실제 운영에서는 암호화 필요
            email: email,
            registrationDate: new Date().toISOString(),
            lastLogin: null
        };

        // 사용자 추가
        UserManager.addUser(userData);

        // 성공 메시지 표시
        showMessage('회원가입이 완료되었습니다! 로그인해주세요.', 'success');

        // 폼 초기화
        document.getElementById('registerForm').reset();

        // 필드 색상 초기화
        ['username', 'password', 'password2', 'email'].forEach(fieldId => {
            document.getElementById(fieldId).style.borderColor = '';
        });

        // 2초 후 로그인 페이지로 이동 (선택사항)
        setTimeout(() => {
            if (confirm('로그인 페이지로 이동하시겠습니까?')) {
                window.location.href = 'Flatfish-c.html'; // 로그인 페이지로 이동
            }
        }, 2000);

    } catch (error) {
        console.error('회원가입 에러:', error);
        showMessage('회원가입 중 오류가 발생했습니다. 다시 시도해주세요.', 'error');
    }
}

// 페이지 로드 완료 후 실행
document.addEventListener('DOMContentLoaded', function() {
    // 폼 제출 이벤트 연결
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    // 실시간 유효성 검사 설정
    setupRealTimeValidation();

    // 저장된 사용자 목록 확인 (개발용)
    console.log('현재 등록된 사용자:', UserManager.getUsers());
});

// 테스트용 함수들 (개발용)
function showAllUsers() {
    console.table(UserManager.getUsers());
}

function clearAllUsers() {
    if (confirm('모든 사용자 데이터를 삭제하시겠습니까?')) {
        localStorage.removeItem('flatfish_users');
        console.log('모든 사용자 데이터가 삭제되었습니다.');
    }
}

// 전역으로 노출 (개발용)
window.showAllUsers = showAllUsers;
window.clearAllUsers = clearAllUsers;