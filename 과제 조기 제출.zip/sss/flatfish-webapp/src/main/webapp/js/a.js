// 회원가입 페이지로 이동
function goToFlatfishB() {
    window.location.href = 'Flatfish-create-id.jsp';
}

// 로그인 페이지로 이동
function goToFlatfishC() {
    window.location.href = 'Flatfish-login.jsp';
}

// 가자미 도감 페이지로 이동
function goToFlatfishD() {
    alert('가자미 도감으로 이동합니다..');
    window.location.href = 'Flatfish-date.jsp';
    }

// 기타 해양생물 페이지로 이동
function goToFlatfishE() {
    alert('기타 해양생물 코너로 이동합니다..');
    window.location.href = 'sea-animal.jsp';
}