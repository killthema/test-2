// SeaDAO.java 코드
package com.flatfish.dao;

import java.sql.*;
import java.util.*;
import com.flatfish.dto.Sea; // 이 부분이 중요합니다

public class SeaDAO {
    private final String URL = "jdbc:mariadb://localhost:3306/marine";
    private final String USER = "root";
    private final String PASS = "1234";

    public List<Sea> getAllSpecies() {
        List<Sea> list = new ArrayList<>();
        String sql = "SELECT * FROM sea";

        // JDBC 드라이버 로드는 최신 버전에서는 선택사항이지만, 명시적으로 작성합니다.
        try {
            Class.forName("org.mariadb.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MariaDB JDBC Driver를 찾을 수 없습니다.");
            e.printStackTrace();
        }
        
        try (
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                Sea sea = new Sea();
                sea.setSpeciesId(rs.getInt("species_id"));
                sea.setKoreanName(rs.getString("korean_name"));
                sea.setScientificName(rs.getString("scientific_name"));
                sea.setEnglishName(rs.getString("english_name"));
                sea.setFamilyName(rs.getString("family_name"));
                sea.setMaxLength(rs.getDouble("max_length"));
                sea.setMaxWeight(rs.getDouble("max_weight"));
                sea.setLifespan(rs.getInt("lifespan"));
                sea.setHabitatDepthMin(rs.getInt("habitat_depth_min"));
                sea.setHabitatDepthMax(rs.getInt("habitat_depth_max"));
                sea.setWaterTempMin(rs.getDouble("water_temp_min"));
                sea.setWaterTempMax(rs.getDouble("water_temp_max"));
                sea.setBreedingSeason(rs.getString("breeding_season"));
                sea.setConservationStatus(rs.getString("conservation_status"));
                sea.setDescription(rs.getString("description"));
                sea.setImageUrl(rs.getString("image_url"));
                sea.setCreateDate(rs.getTimestamp("create_date"));
                sea.setUpdateDate(rs.getTimestamp("update_date"));
                
                list.add(sea);
            }
        } catch (SQLException e) {
            System.err.println("데이터베이스 오류가 발생했습니다.");
            e.printStackTrace();
        }

        return list;
    }
}