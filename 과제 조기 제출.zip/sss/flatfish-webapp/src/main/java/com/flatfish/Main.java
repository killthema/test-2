// 파일 위치: src/com/flatfish/Main.java
package com.flatfish;

import com.flatfish.dao.SeaDAO;
import com.flatfish.dto.Sea;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        SeaDAO dao = new SeaDAO();
        List<Sea> speciesList = dao.getAllSpecies();

        if (speciesList.isEmpty()) {
            System.out.println("데이터베이스에서 데이터를 가져오지 못했습니다.");
        } else {
            System.out.println("데이터를 성공적으로 가져왔습니다!");
            for (Sea species : speciesList) {
                System.out.println("이름: " + species.getKoreanName() + ", 학명: " + species.getScientificName());
            }
        }
    }
}