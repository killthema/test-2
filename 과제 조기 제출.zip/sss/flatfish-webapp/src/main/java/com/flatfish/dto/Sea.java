// Sea.java 코드
package com.flatfish.dto;

import java.sql.Timestamp;

public class Sea {
    private int speciesId;
    private String koreanName;
    private String scientificName;
    private String englishName;
    private String familyName;
    private double maxLength;
    private double maxWeight;
    private int lifespan;
    private int habitatDepthMin;
    private int habitatDepthMax;
    private double waterTempMin;
    private double waterTempMax;
    private String breedingSeason;
    private String conservationStatus;
    private String description;
    private String imageUrl;
    private Timestamp createDate;
    private Timestamp updateDate;

    // Getter 및 Setter 메서드
    public int getSpeciesId() { return speciesId; }
    public void setSpeciesId(int speciesId) { this.speciesId = speciesId; }
    
    public String getKoreanName() { return koreanName; }
    public void setKoreanName(String koreanName) { this.koreanName = koreanName; }
    
    public String getScientificName() { return scientificName; }
    public void setScientificName(String scientificName) { this.scientificName = scientificName; }
    
    public String getEnglishName() { return englishName; }
    public void setEnglishName(String englishName) { this.englishName = englishName; }

    public String getFamilyName() { return familyName; }
    public void setFamilyName(String familyName) { this.familyName = familyName; }

    public double getMaxLength() { return maxLength; }
    public void setMaxLength(double maxLength) { this.maxLength = maxLength; }

    public double getMaxWeight() { return maxWeight; }
    public void setMaxWeight(double maxWeight) { this.maxWeight = maxWeight; }

    public int getLifespan() { return lifespan; }
    public void setLifespan(int lifespan) { this.lifespan = lifespan; }

    public int getHabitatDepthMin() { return habitatDepthMin; }
    public void setHabitatDepthMin(int habitatDepthMin) { this.habitatDepthMin = habitatDepthMin; }

    public int getHabitatDepthMax() { return habitatDepthMax; }
    public void setHabitatDepthMax(int habitatDepthMax) { this.habitatDepthMax = habitatDepthMax; }

    public double getWaterTempMin() { return waterTempMin; }
    public void setWaterTempMin(double waterTempMin) { this.waterTempMin = waterTempMin; }

    public double getWaterTempMax() { return waterTempMax; }
    public void setWaterTempMax(double waterTempMax) { this.waterTempMax = waterTempMax; }

    public String getBreedingSeason() { return breedingSeason; }
    public void setBreedingSeason(String breedingSeason) { this.breedingSeason = breedingSeason; }

    public String getConservationStatus() { return conservationStatus; }
    public void setConservationStatus(String conservationStatus) { this.conservationStatus = conservationStatus; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public Timestamp getCreateDate() { return createDate; }
    public void setCreateDate(Timestamp createDate) { this.createDate = createDate; }

    public Timestamp getUpdateDate() { return updateDate; }
    public void setUpdateDate(Timestamp updateDate) { this.updateDate = updateDate; }
}