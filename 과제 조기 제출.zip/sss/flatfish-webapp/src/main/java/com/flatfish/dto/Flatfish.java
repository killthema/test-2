package com.flatfish.dto;


import java.math.BigDecimal;
import java.sql.Timestamp;

public class Flatfish {
    private int speciesId;
    private String koreanName;
    private String scientificName;
    private String englishName;
    private String familyName;
    private BigDecimal maxLength;
    private BigDecimal maxWeight;
    private Integer lifespan;
    private Integer habitatDepthMin;
    private Integer habitatDepthMax;
    private BigDecimal waterTempMin;
    private BigDecimal waterTempMax;
    private String breedingSeason;
    private String conservationStatus;
    private String description;
    private String imageUrl;
    private Timestamp createDate;
    private Timestamp updateDate;
    
    // 기본 생성자
    public Flatfish() {}
    
    // Getter/Setter 메소드들
    public int getSpeciesId() { return speciesId; }
    public void setSpeciesId(int speciesId) { this.speciesId = speciesId; }
    
    public String getKoreanName() { return koreanName; }
    public void setKoreanName(String koreanName) { this.koreanName = koreanName; }
    
    public String getScientificName() { return scientificName; }
    public void setScientificName(String scientificName) { this.scientificName = scientificName; }
    
    public String getEnglishName() { return englishName; }
    public void setEnglishName(String englishName) { this.englishName = englishName; }
    
    public String getFamilyName() { return familyName; }
    public void setFamilyName(String familyName) { this.familyName = familyName; }
    
    public BigDecimal getMaxLength() { return maxLength; }
    public void setMaxLength(BigDecimal maxLength) { this.maxLength = maxLength; }
    
    public BigDecimal getMaxWeight() { return maxWeight; }
    public void setMaxWeight(BigDecimal maxWeight) { this.maxWeight = maxWeight; }
    
    public Integer getLifespan() { return lifespan; }
    public void setLifespan(Integer lifespan) { this.lifespan = lifespan; }
    
    public Integer getHabitatDepthMin() { return habitatDepthMin; }
    public void setHabitatDepthMin(Integer habitatDepthMin) { this.habitatDepthMin = habitatDepthMin; }
    
    public Integer getHabitatDepthMax() { return habitatDepthMax; }
    public void setHabitatDepthMax(Integer habitatDepthMax) { this.habitatDepthMax = habitatDepthMax; }
    
    public BigDecimal getWaterTempMin() { return waterTempMin; }
    public void setWaterTempMin(BigDecimal waterTempMin) { this.waterTempMin = waterTempMin; }
    
    public BigDecimal getWaterTempMax() { return waterTempMax; }
    public void setWaterTempMax(BigDecimal waterTempMax) { this.waterTempMax = waterTempMax; }
    
    public String getBreedingSeason() { return breedingSeason; }
    public void setBreedingSeason(String breedingSeason) { this.breedingSeason = breedingSeason; }
    
    public String getConservationStatus() { return conservationStatus; }
    public void setConservationStatus(String conservationStatus) { this.conservationStatus = conservationStatus; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    
    public Timestamp getCreateDate() { return createDate; }
    public void setCreateDate(Timestamp createDate) { this.createDate = createDate; }
    
    public Timestamp getUpdateDate() { return updateDate; }
    public void setUpdateDate(Timestamp updateDate) { this.updateDate = updateDate; }
}