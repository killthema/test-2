package com.flatfish.dao;

import com.flatfish.dto.Flatfish;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FlatfishDAO {
    
    // 모든 넙치류 정보 조회
    public List<Flatfish> getAllFlatfish() {
        List<Flatfish> flatfishList = new ArrayList<>();
        String sql = "SELECT * FROM flatfish ORDER BY species_id";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Flatfish flatfish = createFlatfishFromResultSet(rs);
                flatfishList.add(flatfish);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return flatfishList;
    }
    
    // 특정 넙치류 정보 조회 (ID로)
    public Flatfish getFlatfishById(int speciesId) {
        String sql = "SELECT * FROM flatfish WHERE species_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, speciesId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return createFlatfishFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    // 한국명으로 검색
    public List<Flatfish> searchFlatfishByKoreanName(String searchName) {
        List<Flatfish> flatfishList = new ArrayList<>();
        String sql = "SELECT * FROM flatfish WHERE korean_name LIKE ? ORDER BY korean_name";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, "%" + searchName + "%");
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Flatfish flatfish = createFlatfishFromResultSet(rs);
                flatfishList.add(flatfish);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return flatfishList;
    }
    
    // ResultSet에서 Flatfish 객체 생성 (중복 코드 제거)
    private Flatfish createFlatfishFromResultSet(ResultSet rs) throws SQLException {
        Flatfish flatfish = new Flatfish();
        flatfish.setSpeciesId(rs.getInt("species_id"));
        flatfish.setKoreanName(rs.getString("korean_name"));
        flatfish.setScientificName(rs.getString("scientific_name"));
        flatfish.setEnglishName(rs.getString("english_name"));
        flatfish.setFamilyName(rs.getString("family_name"));
        flatfish.setMaxLength(rs.getBigDecimal("max_length"));
        flatfish.setMaxWeight(rs.getBigDecimal("max_weight"));
        flatfish.setLifespan(rs.getObject("lifespan", Integer.class));
        flatfish.setHabitatDepthMin(rs.getObject("habitat_depth_min", Integer.class));
        flatfish.setHabitatDepthMax(rs.getObject("habitat_depth_max", Integer.class));
        flatfish.setWaterTempMin(rs.getBigDecimal("water_temp_min"));
        flatfish.setWaterTempMax(rs.getBigDecimal("water_temp_max"));
        flatfish.setBreedingSeason(rs.getString("breeding_season"));
        flatfish.setConservationStatus(rs.getString("conservation_status"));
        flatfish.setDescription(rs.getString("description"));
        flatfish.setImageUrl(rs.getString("image_url"));
        flatfish.setCreateDate(rs.getTimestamp("create_date"));
        flatfish.setUpdateDate(rs.getTimestamp("update_date"));
        return flatfish;
    }
}