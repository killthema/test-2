// 한글 인코딩 유틸리티 함수
function decodeKorean(str) {
    try {
        return decodeURIComponent(escape(str));
    } catch (e) {
        return str;
    }
}

// 한글 안전 출력 함수
function safeKoreanLog(message) {
    console.log(decodeKorean(message));
}