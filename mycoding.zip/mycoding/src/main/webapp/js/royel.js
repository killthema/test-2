// royel.js - 수정된 버전

// 전역 변수 (JSP에서 전달받을 예정)
let selectedDestination = '';
let selectedCommand = '';

function selectDestination(destination, element) {
    // 기존 선택 해제
    document.querySelectorAll('.destination-card').forEach(card => {
        card.classList.remove('selected');
    });

    // 새로운 선택
    element.classList.add('selected');
    selectedDestination = destination;

    // 히든 필드 업데이트
    const hiddenDestination = document.getElementById('hiddenDestination');
    const selectedDestinationSpan = document.getElementById('selectedDestination');
    
    if (hiddenDestination) {
        hiddenDestination.value = destination;
    }
    if (selectedDestinationSpan) {
        selectedDestinationSpan.textContent = destination;
    }

    updateExecuteButton();
    
    // 한글 로그 출력 테스트
    console.log('목적지 선택됨:', destination);
}

function selectCommand(command, element) {
    // 기존 선택 해제
    document.querySelectorAll('.command-card').forEach(card => {
        card.classList.remove('selected');
    });

    // 새로운 선택
    element.classList.add('selected');
    selectedCommand = command;

    // 히든 필드 업데이트
    const hiddenCommand = document.getElementById('hiddenCommand');
    const selectedCommandSpan = document.getElementById('selectedCommand');
    
    if (hiddenCommand) {
        hiddenCommand.value = command;
    }
    if (selectedCommandSpan) {
        selectedCommandSpan.textContent = command;
    }

    updateExecuteButton();
    
    // 한글 로그 출력 테스트
    console.log('어명 선택됨:', command);
}

function updateExecuteButton() {
    const executeBtn = document.getElementById('executeBtn');
    const warning = document.getElementById('selectionWarning');

    if (selectedDestination && selectedCommand) {
        if (executeBtn) {
            executeBtn.disabled = false;
            executeBtn.innerHTML = '🚀 어명 전달 실행';
        }
        if (warning) {
            warning.style.display = 'none';
        }

        // 선택된 조합에 따른 메시지 표시
        showDeliveryPreview();
    } else {
        if (executeBtn) {
            executeBtn.disabled = true;
            executeBtn.innerHTML = '선택을 완료해주세요';
        }
        if (warning) {
            warning.style.display = 'block';
        }
    }
}

function showDeliveryPreview() {
    let urgencyMsg = "";
    let color = "#3498db";

    if (selectedCommand === "칙명") {
        urgencyMsg = "⚠️ 극비 사안 - 즉시 전달 필요";
        color = "#e74c3c";
    } else if (selectedCommand === "포고") {
        urgencyMsg = "📢 공개 발표 - 신속한 전파 필요";
        color = "#1976d2";
    } else if (selectedCommand === "교지") {
        urgencyMsg = "📋 공무 수행 - 정해진 일정에 따라 전달";
        color = "#7b1fa2";
    } else if (selectedCommand === "봉서") {
        urgencyMsg = "📝 임무 부여 - 적절한 시기에 전달";
        color = "#f57c00";
    }

    // 한글 로그가 깨지지 않도록 출력
    console.log('선택 조합:', selectedCommand, '→', selectedDestination);
    console.log('긴급도 메시지:', urgencyMsg);
    
    // 전달 세부사항 업데이트
    updateDeliveryDetails(urgencyMsg, color);
}

function updateDeliveryDetails(urgencyMsg, color) {
    const deliveryDetails = document.getElementById('deliveryDetails');
    if (deliveryDetails && selectedDestination && selectedCommand) {
        deliveryDetails.innerHTML = `
            <div style="padding: 10px; border-left: 4px solid ${color}; background: #f8f9fa;">
                <p><strong>전달 준비 정보:</strong></p>
                <ul>
                    <li><strong>대상:</strong> ${selectedDestination}</li>
                    <li><strong>어명:</strong> ${selectedCommand}</li>
                    <li><strong>긴급도:</strong> <span style="color: ${color};">${urgencyMsg}</span></li>
                    <li><strong>상태:</strong> 전달 준비 완료</li>
                </ul>
            </div>
        `;
    }
}

// JSP에서 전달받은 데이터로 초기화
function initializeFromPageData() {
    if (window.pageData) {
        // JSP에서 전달받은 선택값으로 초기화
        if (window.pageData.selectedDestination) {
            selectedDestination = window.pageData.selectedDestination;
            console.log('초기 목적지 설정됨:', selectedDestination);
            
            // 해당 카드를 선택된 상태로 표시
            const destinationCard = document.querySelector(`[onclick*="${selectedDestination}"]`);
            if (destinationCard) {
                destinationCard.classList.add('selected');
            }
        }
        
        if (window.pageData.selectedCommand) {
            selectedCommand = window.pageData.selectedCommand;
            console.log('초기 어명 설정됨:', selectedCommand);
            
            // 해당 카드를 선택된 상태로 표시
            const commandCard = document.querySelector(`[onclick*="${selectedCommand}"]`);
            if (commandCard) {
                commandCard.classList.add('selected');
            }
        }
        
        // 버튼 상태 업데이트
        updateExecuteButton();
        
        // 통계 정보 로그
        console.log('시스템 통계:');
        console.log('- 긴급 어명 수:', window.pageData.urgentCount);
        console.log('- 전체 어명 수:', window.pageData.totalMessages);
        
        // 긴급 어명 경고 표시
        if (window.pageData.urgentCount > 0) {
            console.warn(`⚠️ 긴급 어명 ${window.pageData.urgentCount}개 대기중!`);
        }
    }
}

// 한글 텍스트 안전 출력 함수
function safeKoreanLog(message) {
    try {
        console.log(decodeURIComponent(escape(message)));
    } catch (e) {
        console.log(message); // 실패하면 원본 그대로 출력
    }
}

// DOM 로드 완료 시 초기화
document.addEventListener('DOMContentLoaded', function() {
    console.log('🏛️ 왕실 어명 시스템 JavaScript 로드 완료');
    
    // JSP 데이터로 초기화
    initializeFromPageData();
    
    // 페이지 로드 시 버튼 상태 체크
    updateExecuteButton();
    
    console.log('시스템 준비 완료 ✅');
});

// 페이지 언로드 시 정리
window.addEventListener('beforeunload', function() {
    console.log('페이지를 떠납니다. 선택된 정보:', {
        destination: selectedDestination,
        command: selectedCommand
    });
});