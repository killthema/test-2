package com.mycoding.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import db.DBConnection;
import com.mycoding.dto.RoyalMessage;

public class RoyalMessageDAO {
    
    private DBConnection dbConnection;
    
    public RoyalMessageDAO() {
        this.dbConnection = DBConnection.getInstance();
    }
    
    // 모든 어명 조회
    public List<RoyalMessage> getAllMessages() throws SQLException {
        List<RoyalMessage> messages = new ArrayList<>();
        String sql = "SELECT * FROM royal_messages ORDER BY create_date DESC";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                messages.add(mapResultSetToRoyalMessage(rs));
            }
        }
        return messages;
    }
    
    // ID로 특정 어명 조회
    public RoyalMessage getMessageById(int messageId) throws SQLException {
        String sql = "SELECT * FROM royal_messages WHERE message_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, messageId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToRoyalMessage(rs);
                }
            }
        }
        return null;
    }
    
    // 긴급도별 어명 조회
    public List<RoyalMessage> getMessagesByUrgency(String urgencyLevel) throws SQLException {
        List<RoyalMessage> messages = new ArrayList<>();
        String sql = "SELECT * FROM royal_messages WHERE urgency_level = ? ORDER BY create_date DESC";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, urgencyLevel);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    messages.add(mapResultSetToRoyalMessage(rs));
                }
            }
        }
        return messages;
    }
    
    // 전달 상태별 어명 조회
    public List<RoyalMessage> getMessagesByStatus(String deliveryStatus) throws SQLException {
        List<RoyalMessage> messages = new ArrayList<>();
        String sql = "SELECT * FROM royal_messages WHERE delivery_status = ? ORDER BY create_date DESC";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, deliveryStatus);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    messages.add(mapResultSetToRoyalMessage(rs));
                }
            }
        }
        return messages;
    }
    
    // 새 어명 추가
    public boolean insertMessage(RoyalMessage message) throws SQLException {
        String sql = "INSERT INTO royal_messages (message_type, destination, destination_official, " +
                    "urgency_level, security_level, messenger_assigned, delivery_method, " +
                    "estimated_time, travel_route, weather_condition, road_condition, season, " +
                    "emergency_level, situation_type, priority_score, risk_level, delivery_status, " +
                    "message_content, special_instructions, contingency_plans) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, message.getMessageType());
            pstmt.setString(2, message.getDestination());
            pstmt.setString(3, message.getDestinationOfficial());
            pstmt.setString(4, message.getUrgencyLevel());
            pstmt.setString(5, message.getSecurityLevel());
            pstmt.setString(6, message.getMessengerAssigned());
            pstmt.setString(7, message.getDeliveryMethod());
            pstmt.setString(8, message.getEstimatedTime());
            pstmt.setString(9, message.getTravelRoute());
            pstmt.setString(10, message.getWeatherCondition());
            pstmt.setString(11, message.getRoadCondition());
            pstmt.setString(12, message.getSeason());
            pstmt.setString(13, message.getEmergencyLevel());
            pstmt.setString(14, message.getSituationType());
            pstmt.setInt(15, message.getPriorityScore());
            pstmt.setInt(16, message.getRiskLevel());
            pstmt.setString(17, message.getDeliveryStatus());
            pstmt.setString(18, message.getMessageContent());
            pstmt.setString(19, message.getSpecialInstructions());
            pstmt.setString(20, message.getContingencyPlans());
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // 어명 상태 업데이트
    public boolean updateMessageStatus(int messageId, String newStatus) throws SQLException {
        String sql = "UPDATE royal_messages SET delivery_status = ?, update_date = CURRENT_TIMESTAMP WHERE message_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, messageId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // 발송 시간 업데이트
    public boolean updateDispatchTime(int messageId) throws SQLException {
        String sql = "UPDATE royal_messages SET dispatch_date = CURRENT_TIMESTAMP, " +
                    "delivery_status = '진행중', update_date = CURRENT_TIMESTAMP WHERE message_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, messageId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // 전달 완료 처리
    public boolean completeDelivery(int messageId, String completionNotes) throws SQLException {
        String sql = "UPDATE royal_messages SET delivery_date = CURRENT_TIMESTAMP, " +
                    "delivery_status = '완료', completion_notes = ?, update_date = CURRENT_TIMESTAMP WHERE message_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, completionNotes);
            pstmt.setInt(2, messageId);
            
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // 어명 삭제
    public boolean deleteMessage(int messageId) throws SQLException {
        String sql = "DELETE FROM royal_messages WHERE message_id = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, messageId);
            return pstmt.executeUpdate() > 0;
        }
    }
    
    // 통계 조회 - 상태별 개수
    public int getCountByStatus(String status) throws SQLException {
        String sql = "SELECT COUNT(*) FROM royal_messages WHERE delivery_status = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        return 0;
    }
    
    // ResultSet을 RoyalMessage 객체로 변환하는 헬퍼 메소드
    private RoyalMessage mapResultSetToRoyalMessage(ResultSet rs) throws SQLException {
        RoyalMessage message = new RoyalMessage();
        
        message.setMessageId(rs.getInt("message_id"));
        message.setMessageType(rs.getString("message_type"));
        message.setDestination(rs.getString("destination"));
        message.setDestinationOfficial(rs.getString("destination_official"));
        message.setUrgencyLevel(rs.getString("urgency_level"));
        message.setSecurityLevel(rs.getString("security_level"));
        message.setMessengerAssigned(rs.getString("messenger_assigned"));
        message.setDeliveryMethod(rs.getString("delivery_method"));
        message.setEstimatedTime(rs.getString("estimated_time"));
        message.setTravelRoute(rs.getString("travel_route"));
        message.setWeatherCondition(rs.getString("weather_condition"));
        message.setRoadCondition(rs.getString("road_condition"));
        message.setSeason(rs.getString("season"));
        message.setEmergencyLevel(rs.getString("emergency_level"));
        message.setSituationType(rs.getString("situation_type"));
        message.setPriorityScore(rs.getInt("priority_score"));
        message.setRiskLevel(rs.getInt("risk_level"));
        message.setDeliveryStatus(rs.getString("delivery_status"));
        message.setMessageContent(rs.getString("message_content"));
        message.setSpecialInstructions(rs.getString("special_instructions"));
        message.setContingencyPlans(rs.getString("contingency_plans"));
        message.setCompletionNotes(rs.getString("completion_notes"));
        message.setCreateDate(rs.getTimestamp("create_date"));
        message.setDispatchDate(rs.getTimestamp("dispatch_date"));
        message.setDeliveryDate(rs.getTimestamp("delivery_date"));
        message.setUpdateDate(rs.getTimestamp("update_date"));
        
        return message;
    }
}