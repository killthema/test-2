package com.mycoding.dto;


import java.sql.Timestamp;

public class RoyalMessage {
    private int messageId;
    private String messageType;
    private String destination;
    private String destinationOfficial;
    private String urgencyLevel;
    private String securityLevel;
    private String messengerAssigned;
    private String deliveryMethod;
    private String estimatedTime;
    private String travelRoute;
    private String weatherCondition;
    private String roadCondition;
    private String season;
    private String emergencyLevel;
    private String situationType;
    private int priorityScore;
    private int riskLevel;
    private String deliveryStatus;
    private String messageContent;
    private String specialInstructions;
    private String contingencyPlans;
    private String completionNotes;
    private Timestamp createDate;
    private Timestamp dispatchDate;
    private Timestamp deliveryDate;
    private Timestamp updateDate;

    // 기본 생성자
    public RoyalMessage() {}

    // 전체 필드 생성자
    public RoyalMessage(String messageType, String destination, String destinationOfficial,
                       String urgencyLevel, String securityLevel, String messengerAssigned,
                       String deliveryMethod, String estimatedTime, String travelRoute,
                       String weatherCondition, String roadCondition, String season,
                       String emergencyLevel, String situationType, int priorityScore,
                       int riskLevel, String deliveryStatus, String messageContent,
                       String specialInstructions, String contingencyPlans) {
        this.messageType = messageType;
        this.destination = destination;
        this.destinationOfficial = destinationOfficial;
        this.urgencyLevel = urgencyLevel;
        this.securityLevel = securityLevel;
        this.messengerAssigned = messengerAssigned;
        this.deliveryMethod = deliveryMethod;
        this.estimatedTime = estimatedTime;
        this.travelRoute = travelRoute;
        this.weatherCondition = weatherCondition;
        this.roadCondition = roadCondition;
        this.season = season;
        this.emergencyLevel = emergencyLevel;
        this.situationType = situationType;
        this.priorityScore = priorityScore;
        this.riskLevel = riskLevel;
        this.deliveryStatus = deliveryStatus;
        this.messageContent = messageContent;
        this.specialInstructions = specialInstructions;
        this.contingencyPlans = contingencyPlans;
    }

    // Getter 및 Setter 메소드들
    public int getMessageId() { return messageId; }
    public void setMessageId(int messageId) { this.messageId = messageId; }

    public String getMessageType() { return messageType; }
    public void setMessageType(String messageType) { this.messageType = messageType; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public String getDestinationOfficial() { return destinationOfficial; }
    public void setDestinationOfficial(String destinationOfficial) { this.destinationOfficial = destinationOfficial; }

    public String getUrgencyLevel() { return urgencyLevel; }
    public void setUrgencyLevel(String urgencyLevel) { this.urgencyLevel = urgencyLevel; }

    public String getSecurityLevel() { return securityLevel; }
    public void setSecurityLevel(String securityLevel) { this.securityLevel = securityLevel; }

    public String getMessengerAssigned() { return messengerAssigned; }
    public void setMessengerAssigned(String messengerAssigned) { this.messengerAssigned = messengerAssigned; }

    public String getDeliveryMethod() { return deliveryMethod; }
    public void setDeliveryMethod(String deliveryMethod) { this.deliveryMethod = deliveryMethod; }

    public String getEstimatedTime() { return estimatedTime; }
    public void setEstimatedTime(String estimatedTime) { this.estimatedTime = estimatedTime; }

    public String getTravelRoute() { return travelRoute; }
    public void setTravelRoute(String travelRoute) { this.travelRoute = travelRoute; }

    public String getWeatherCondition() { return weatherCondition; }
    public void setWeatherCondition(String weatherCondition) { this.weatherCondition = weatherCondition; }

    public String getRoadCondition() { return roadCondition; }
    public void setRoadCondition(String roadCondition) { this.roadCondition = roadCondition; }

    public String getSeason() { return season; }
    public void setSeason(String season) { this.season = season; }

    public String getEmergencyLevel() { return emergencyLevel; }
    public void setEmergencyLevel(String emergencyLevel) { this.emergencyLevel = emergencyLevel; }

    public String getSituationType() { return situationType; }
    public void setSituationType(String situationType) { this.situationType = situationType; }

    public int getPriorityScore() { return priorityScore; }
    public void setPriorityScore(int priorityScore) { this.priorityScore = priorityScore; }

    public int getRiskLevel() { return riskLevel; }
    public void setRiskLevel(int riskLevel) { this.riskLevel = riskLevel; }

    public String getDeliveryStatus() { return deliveryStatus; }
    public void setDeliveryStatus(String deliveryStatus) { this.deliveryStatus = deliveryStatus; }

    public String getMessageContent() { return messageContent; }
    public void setMessageContent(String messageContent) { this.messageContent = messageContent; }

    public String getSpecialInstructions() { return specialInstructions; }
    public void setSpecialInstructions(String specialInstructions) { this.specialInstructions = specialInstructions; }

    public String getContingencyPlans() { return contingencyPlans; }
    public void setContingencyPlans(String contingencyPlans) { this.contingencyPlans = contingencyPlans; }

    public String getCompletionNotes() { return completionNotes; }
    public void setCompletionNotes(String completionNotes) { this.completionNotes = completionNotes; }

    public Timestamp getCreateDate() { return createDate; }
    public void setCreateDate(Timestamp createDate) { this.createDate = createDate; }

    public Timestamp getDispatchDate() { return dispatchDate; }
    public void setDispatchDate(Timestamp dispatchDate) { this.dispatchDate = dispatchDate; }

    public Timestamp getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(Timestamp deliveryDate) { this.deliveryDate = deliveryDate; }

    public Timestamp getUpdateDate() { return updateDate; }
    public void setUpdateDate(Timestamp updateDate) { this.updateDate = updateDate; }

    @Override
    public String toString() {
        return "RoyalMessage{" +
                "messageId=" + messageId +
                ", messageType='" + messageType + '\'' +
                ", destination='" + destination + '\'' +
                ", urgencyLevel='" + urgencyLevel + '\'' +
                ", deliveryStatus='" + deliveryStatus + '\'' +
                '}';
    }
}